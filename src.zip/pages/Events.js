import React from 'react';
import Footer from '../components/navigation/Footer';
import './Events.css';

const Events = () => {

  return(
    <React.Fragment>
      <h1>이벤트 페이지 입니다.</h1>
      <Footer />
    </React.Fragment>
    
  )
};

export default Events;